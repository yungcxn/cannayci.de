def generate(n):
    for i in [1,2,3,4,5]:
        yield i

my_generator = generate(10)

print(my_generator)

print(next(my_generator))
print(next(my_generator))
print(next(my_generator))
print(next(my_generator))
print(next(my_generator))
