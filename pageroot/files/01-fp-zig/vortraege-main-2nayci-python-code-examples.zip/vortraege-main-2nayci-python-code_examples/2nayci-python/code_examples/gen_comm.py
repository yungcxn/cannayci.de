def infinite_2power():
    i=1
    while True:
        sent_value = yield i
        if sent_value is not None:  # if something was sent
            i = sent_value
        else:                       # nothing sent
            i += i

my_gen = infinite_2power()

for i in range(10):         # print first 10 squares
    print(next(my_gen))

print("Sending 100 to my_gen...")
print(my_gen.send(100))

for i in range(10):         # print another 10 squares
    print(next(my_gen))

my_gen.close()