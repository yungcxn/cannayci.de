import functools

def add(a,b):
    return a + b

A = [1,2,3,4,5]

print("reduce:")
value = functools.reduce(add, A)
#       functools.reduce(add, A, 0)

print(value)


print("with operator:")
import operator
value = functools.reduce(operator.add, A)
print(value)


print("iterator with itertools:")
import itertools
my_iter = itertools.accumulate(A, add)

for i in range(5):
    print(next(my_iter))


print("partial:")

def mult(a,b):
    return a * b

mult_with_2 = functools.partial(mult, b=2)

print(mult_with_2(4))
