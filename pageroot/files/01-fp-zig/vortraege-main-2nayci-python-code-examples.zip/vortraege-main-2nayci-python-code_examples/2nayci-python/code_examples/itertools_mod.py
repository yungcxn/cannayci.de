import itertools

my_iter = itertools.count(13)

print(next(my_iter))
print(next(my_iter))
print(next(my_iter))


print("steps in 3:")
my_iter = itertools.count(13, 3)

print(next(my_iter))
print(next(my_iter))
print(next(my_iter))


print("endless cycle:")
my_iter = itertools.cycle([1,2,3])

for i in range(6):
    print(next(my_iter))


#itertools.repeat like cycle, but with second argument


print("chained multiple iterables together:")
my_iter = itertools.chain([1,2,3], (4,5,6), ["car", "chair"])

for i in range(8):
    print(next(my_iter))


print("slicing iterators:")
my_iter = itertools.islice([1,2,3,4], 1, 3)

for i in range(2):
    print(next(my_iter))


print("duplicating iterators:")
my_iter = itertools.count()
tuple_of_iterators = itertools.tee(my_iter, 3)

print()
print(tuple_of_iterators)
print()

print(next(tuple_of_iterators[0]))
print(next(tuple_of_iterators[0]))
print(next(tuple_of_iterators[0]))
print(next(tuple_of_iterators[1]))
print(next(tuple_of_iterators[1]))


#itertools.starmap(func, iterator_of_tuples) 
#irrelevant

print("Like filter(), but negated:")
def even(x):
    return x%2==0

uneven_iterator = itertools.filterfalse(even, itertools.count())

for i in range(5):
    print(next(uneven_iterator))


print("Run iterator until true, or drop while true:")

A = [1,2,3,4,5,6,7,8,9,10]

def under_3(x):
    return x < 3

iterator_under3 = itertools.takewhile(under_3, itertools.count())
iterator_over3 = itertools.dropwhile(under_3, itertools.count())

print(next(iterator_under3))
print(next(iterator_under3))
print(next(iterator_under3))
# print(next(iterator_under3)) would throw
print(next(iterator_over3))
print(next(iterator_over3))
print(next(iterator_over3))
# ...


print("Combinations:")
A = [1,2,3,4]

my_iter = itertools.combinations(A, 2)
print(list(my_iter))

my_iter = itertools.combinations(A, 3)
print(list(my_iter))


print("Permutations (Combinations without order):")
A = [1,2,3,4]

my_iter = itertools.permutations(A, 2)
print(list(my_iter))

my_iter = itertools.permutations(A, 3)
print(list(my_iter))

# and others...


print("Grouped iterators:")
def get_first_letter(str):
    return str[0]

item_list = ["apple", "banana", "air", "brown", "can"]

iterator_list = itertools.groupby(item_list, get_first_letter)

tuple1 = next(iterator_list)
tuple2 = next(iterator_list)
iter1 = tuple1[1]
iter2 = tuple2[1]




