lambda_func = lambda a: a*2
lambda_func2 = lambda a,b: a + b

print("lambda:")
print(lambda_func)
print(lambda_func(5))
print(lambda_func2(1,2))

def outer(x):
    def inner(y):
        return x+y
    
    return inner

print("currying:")
print(outer(10)(20))


def func_given(f1):
    a = 5
    b = 5   
    c = 5
    return f1(a,b,c)

def func_3arg(a,b,c):
    return a*b*c

print("function as arg:")
print(func_given(func_3arg))