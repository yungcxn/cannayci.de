A = [1,2,3,4,5]

my_iter = (i+10 for i in A) #genexp

print(my_iter)

my_list = [i+10 for i in A] #listcomp

print(my_list)
print(A)        # Didn't change

print(next(my_iter))

filtered_even_plus1 = [i+1 for i in A if i%2==0]

print(filtered_even_plus1)

#################################################

B = ["aaa", "bbb", "CCC"]
C = ["ddd", "EEE", "fff"]

# this would be a list if []
complex_iterator = (
    i + " " + j 
    for i in B
    if i.islower()
    for j in C
    if j.islower()
) 

print(next(complex_iterator))
print(next(complex_iterator))
print(next(complex_iterator))
print(next(complex_iterator))
# print(next(complex_iterator)) would throw; Iteration over

x_axis = [1,2,3,4,5]
y_axis = [1,2,3,4,5]

print(
    [(x,y) for x in x_axis for y in y_axis]
) 

