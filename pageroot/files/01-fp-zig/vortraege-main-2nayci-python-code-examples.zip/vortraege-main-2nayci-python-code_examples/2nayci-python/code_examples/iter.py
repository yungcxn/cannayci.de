A = ["Erstes Element", "Zweites Element", "Drittes Element"]

iterator1 = iter(A)

print(next(iterator1))
print(next(iterator1))
print(next(iterator1))

print()

iterator2 = iter(A)

for i in iter(iterator2):
    print(i)

print()

iterator3 = iter(A)

for i in iterator3:
    i = "Neuer Wert"

print(A)








