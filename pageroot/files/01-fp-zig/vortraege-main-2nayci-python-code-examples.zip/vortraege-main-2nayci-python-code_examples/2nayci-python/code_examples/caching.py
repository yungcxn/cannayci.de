from functools import cached_property, lru_cache
from datetime import datetime


def uncached_fibo(n):
    if n < 2:
        return n
    return uncached_fibo(n - 1) + uncached_fibo(n - 2)

@lru_cache(maxsize=None)
def cached_fibo(n):
    if n < 2:
        return n
    return cached_fibo(n - 1) + cached_fibo(n - 2)


our_fibo_number1 = 20
our_fibo_number2 = 30


time1 = datetime.now().timestamp()
print("calculated " + str(uncached_fibo(our_fibo_number1)))
time2 = datetime.now().timestamp()
print("calculated " + str(uncached_fibo(our_fibo_number2)))
time3 = datetime.now().timestamp()

time1 = time2-time1
time2 = time3-time2

print("uncached first fibo-number time: " + str(time1))
print("uncached second fibo-number time: " + str(time2))


time1 = datetime.now().timestamp()
print("calculated " + str(cached_fibo(our_fibo_number1)))
time2 = datetime.now().timestamp()
print("calculated " + str(cached_fibo(our_fibo_number2)))
time3 = datetime.now().timestamp()

time1 = time2-time1
time2 = time3-time2

print("cached first fibo-number time: " + str(time1))
print("cached second fibo-number time: " + str(time2))


class my_calculator:

    def __init__(self, N):
        self.N = N

    @cached_property
    def calc_cached(self):
        sum = 0
        print("begin calculating cached...")
        for i in range(self.N):
            sum += i
        
        return sum
    
    def calc_uncached(self):
        sum = 0
        print("begin calculating uncached...")
        for i in range(self.N):
            sum += i
        
        return sum

calc_size = 10000000
mycalc_cached = my_calculator(calc_size)
mycalc_uncached = my_calculator(calc_size)

time1 = datetime.now().timestamp()
val1 = mycalc_cached.calc_cached
time2 = datetime.now().timestamp()
val2 = mycalc_cached.calc_cached
time3 = datetime.now().timestamp()

ratio = (time2-time1) / (time3-time2)

print("Speed-up ratio cached: " + str(ratio))

time1 = datetime.now().timestamp()
val3 = mycalc_uncached.calc_uncached
time2 = datetime.now().timestamp()
val4 = mycalc_uncached.calc_uncached
time3 = datetime.now().timestamp()

ratio = (time2-time1) / (time3-time2)

print("Speed-up ratio uncached: " + str(ratio))