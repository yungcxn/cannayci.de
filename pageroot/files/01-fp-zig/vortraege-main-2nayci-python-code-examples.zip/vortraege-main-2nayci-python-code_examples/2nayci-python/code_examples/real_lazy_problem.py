def infinite_2power():
    i=1
    while True:
        yield i
        i += i

my_gen = infinite_2power()

for i in range(10):         # print first 10 squares
    print(next(my_gen))

my_gen.close()