def generate():
    print("abc")
    yield 5
    print("def")
    yield 6
    print("ghi")
    yield 7

generatorobj = generate()

print(next(generatorobj))
print(next(generatorobj))
print(next(generatorobj))

def generate2():
    print("jkl")
    yield 8
    x = 9 / 0
    yield x

generatorobj = generate2()

print(next(generatorobj))
print(next(generatorobj))