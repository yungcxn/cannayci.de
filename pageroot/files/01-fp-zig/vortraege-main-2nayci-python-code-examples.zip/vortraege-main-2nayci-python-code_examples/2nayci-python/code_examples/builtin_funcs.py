# map -> returns iterator
 
def inc(x):
    return x+1

def my_add(x,y):
    return x+y

A = [1,2,3,4,5]

my_iter = map(inc, A)
print(list(my_iter)) 

my_iter2 = map(my_add, A, A)
print(list(my_iter2)) 

# filter -> returns iterator

# A = [1,2,3,4,5] (as a reminder)

def bigger_as_2(x):
    return x > 2

print(
    list(
        filter(bigger_as_2, A)
    )
)

# enumerate -> returns tuple with (count, obj)

B = ["Apple", "Table", "Chair"]

for i in enumerate(B):
    print(i)

# sorted -> returns sorted list

C = [10, 15, 6, 82, 1]

print(sorted(C))
print(sorted(C, reverse=True))

# any / all -> returns boolean

print(any([0,0,0,1]))
print(any([0,0,0,0]))

print(all([0,0,0,1]))
print(all([1,1,1,1]))

# zip -> tuples out of lists (iterables)

zipped = zip([1,2,3], [4,5,6]) # lazy!

print(next(zipped))
print(next(zipped))
print(next(zipped))